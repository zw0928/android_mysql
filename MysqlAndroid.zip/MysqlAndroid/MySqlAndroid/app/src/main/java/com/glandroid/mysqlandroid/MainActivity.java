package com.glandroid.mysqlandroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.sql.Connection;
import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {

    private static final String REMOTE_IP = "192.168.1.109";
    private static final String URL = "jdbc:mysql://" + REMOTE_IP + "/users";
    private static final String USER = "root";
    private static final String PASSWORD = "weiyi";

    private Button onQuery;
    private Button onConn;
    private Connection conn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        onQuery=(Button) findViewById(R.id.onQuery);
        onConn=(Button) findViewById(R.id.onConn);

    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        if (conn != null);{
            try {
                conn.close();
            } catch (SQLException e) {
                conn = null;
            }finally {
                conn = null;
            }
        }

    }

    public void onConn(View view){
        new Thread(new Runnable() {
            @Override
            public void run() {
                conn = Util.openConnection(URL, USER, PASSWORD);
                Log.i("onConn", "onConn");
            }
        }).start();
    }
    public void onQuery(View view) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Util.query(conn, "select * from users");
                Log.i("onQuery", "onQuery");
            }
        }).start();
    }
}